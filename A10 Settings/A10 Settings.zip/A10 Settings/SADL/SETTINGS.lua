settings=
{
	["own_id"]=1,
	["grp_id"]=8,
	["callsign"]="",
}
